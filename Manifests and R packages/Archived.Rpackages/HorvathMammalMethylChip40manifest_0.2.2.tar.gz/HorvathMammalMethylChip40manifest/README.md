# HorvathMammalMethylChip40manifest

Install the annotation package(s) as

```
library(devtools)
install_bitbucket("khansen/HorvathMammalMethylChip40manifest")
install_bitbucket("khansen/HorvathMammalMethylChip40anno.test.unknown")
```

(clearly the annotation name needs to change (current has `test.unknown`).

You can work with the new arrays in two ways
1. Using a recent, but stable release of Bioconductor.
2. Use the very latest version of minfi (>= 1.27.8)

The second choice means that array type and everything else will be auto-detected.  

## Using minfi devel

To use the development version of minfi do
```
library(BiocManager)
BiocManager::install("minfi", version = "devel")
```
This requires you to switch to the devel version of Bioconductor. If you use R a lot you most likely want to have two R installations - one with Bioconductor stable and one with Bioconductor devel.  This should be available after September 30th. Before you can install from Github (repos is `hansenlab/minfi`)

## Using stable minfi

If you want to use a stable version of Bioconductor which does not auto-detect the new arrays, do the following:
```
RGset <- read.metharray.exp("dats_N092.only/202794570006")
```
you will see something like
```
> RGset
class: RGChannelSet
dim: 41005 12
metadata(0):
assays(2): Green Red
rownames(41005): 1603211 1603289 ... 99810888 99810986
rowData names(0):
colnames(12): 202794570006_R01C01 202794570006_R01C02 ...
  202794570006_R06C01 202794570006_R06C02
colData names(0):
Annotation
  array: Unknown
  annotation: Unknown
```
note all the "Unknown" in the last two lines.  You fix this by running
```
annotation(RGset) <- c("array" = "HorvathMammalMethylChip40", "annotation" = "test.unknown")
```

# What works

- `preprocessRaw()`
- `preprocessNoob()`

# What does not work / todo

- Everything which uses genome coordinates or deals separately with CpGs on the sex chromosomes (eg. `preprocessQuantil()`)
- Kasper needs to think about supporting multiple species coordinates for the same array in minfi.
