library(testthat)
library(sesame)

test_check("sesame")
