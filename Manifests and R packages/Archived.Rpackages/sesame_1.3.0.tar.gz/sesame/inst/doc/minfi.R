## ----message = FALSE-----------------------------------------------------
library(sesame)
library(FlowSorted.Blood.450k)

## ------------------------------------------------------------------------
grSet <- sesamize(FlowSorted.Blood.450k[,1:4])
grSet

